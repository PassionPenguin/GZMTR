let s_inf_244 = {
    "name": ["琶洲大橋南", "琶洲大桥南", "琶洲大橋南-はしゅうだいきょうみなみ", "", "Pazhou Bridge South"],
    "inf": [{
        "platform": 1,
        "facilities": []
    }, {
        "platform": 2,
        "facilities": []
    }],
    "location": [113.375484, 23.104563],
    "via": ["THZ1"],
    "shortDesc": "琶洲大桥南站是海珠有轨电车的一个车站，车站位于阅江东路，琶洲大桥南侧东端之地面，于2014年12月31日随线路开通试乘而启用。\n\n本站在规划期间称为水博苑站。\n",
    "structureType": [0],
    "platformType": [3],
    "hallType": [1],
    "exitNum": [1],
    "openTime": ["2014-12=31_"],
    "serviceTime": "无封闭",
    "firstTrain": [[[0, "07:34"], [1, "07:45"]]],
    "lastTrain": [[[0, "22:45"], [1, "22:19"]]],
    "structureDesc": [["琶洲大桥南站两个侧式站台均设有自动售票机以及多个喷雾风扇。"], ["月台", "本站设有两个侧式月台，位于阅江东路，琶洲大桥南侧东端。\n"]],
    "platformBelong": [["2", "THZ1"], ["1", "THZ1"]]
};
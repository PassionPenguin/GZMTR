/* Made by Penguin */

window.sentences = [
    ["就算你failed佐，我都唔會唔鍾意你[icon]fa fa-heart beating[/icon]", "就算你失败了，我也会爱你呀[icon]fa fa-heart beating[/icon]", "[icon]fa fa-heart beating[/icon]", "[icon]fa fa-heart beating[/icon]", "No matter you successed or not,\n I will love you all the time[icon]fa fa-heart beating[/icon]"],
    ["今日系[icon]fa fa-lemon' style='font-weight:400[/icon] 仲系 [icon]fa fa-apple-alt[/icon] 嘞", "今天是[icon]fa fa-lemon' style='font-weight:400[/icon] 还是 [icon]fa fa-apple-alt[/icon] 呢", "[icon]fa fa-lemon[/icon]", "[icon]fa fa-lemon[/icon]", "What'll be today? [icon]fa fa-lemon' style='font-weight:400[/icon] or [icon]fa fa-apple-alt[/icon] ?"]
];
window.string = {
    infoDesc: ["简介信息", "简介信息", "", "", "Info"],
    facilityDesc: ["车站设施", "车站设施", "", "", "Facilities"],
    locationDesc: ["地理座標", "地理坐标", "", "", "Map Position"],
    lineDesc: ["經過線路", "经过线路", "", "", "Line Passed"],
    codeDesc: ["站點代碼", "站点代码", "", "", "Station Code"],
    structureDesc: ["车站结构", "车站结构", "", "", "Structure Type"],
    structureInfo: [["地下车站", "地下车站", "", "", "Underground Station"], ["地面车站", "地面车站", "", "", "Ground Station"], ["高架车站", "高架车站", "", "", "Overground Station"]],
    platformDesc: ["月台类型", "月台类型", "", "", "Platform Type"],
    platformInfo: [["岛式站台", "岛式站台", "", "", "Island Platform"], ["侧式站台", "侧式站台", "", "", "Side Platform"], ["双岛式站台", "双岛式站台", "", "", "DblIsland Platform"], ["双侧式站台", "双侧式站台", "", "", "DblSide Platform"], ["完全混合式站台", "完全混合式站台", "", "", "Mixed Platform"], ["西班牙式站台", "西班牙式站台", "", "", "Spanish solution"], ["分离岛式站台", "分离岛式站台", "", "", "Split Platform"]],
    hallDesc: ["站厅类型", "站厅类型", "", "", "Hall Type"],
    hallInfo: [["地下站厅", "地下站厅", "", "", "Underground Station"], ["地面站厅", "地面站厅", "", "", "Ground Station"], ["高架站厅", "高架站厅", "", "", "Overground Station"]],
    transferDesc: ["换乘方式", "换乘方式", "", "", "Transfer Type"],
    transferInfo: [["同台换乘", "同台换乘", "", "", "Transfer at the opposite"], ["通道换乘", "通道换乘", "", "", "Via Passage"], ["站厅换乘", "站厅换乘", "", "", "Via Hall"]],
    exitNum: ["出口数量", "出口数量", "", "", "Exits Num"],
    FirstTrainDesc: ["首班车", "首班车", "", "", "First Train Time"],
    LastTrainDesc: ["末班车", "末班车", "", "", "Last Train Time"],
    serviceTimeDesc: ["服务时间", "服务时间", "", "", "Service Time"],
    structureName: ["结构", "结构", "", "", "Structure"],
    historyName: ["历史", "历史", "", "", "History"],
    futureExName: ["未来拓展", "未来拓展", "", "", "Future Expansion"]
};